package android.lowestcost.photon.com.lowestcost;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *  This Activity is used for find the Path of Lowest Cost in given Gride
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //GUI view declaration
    private EditText x1y1,x1y2,x1y3,x1y4,x1y5,x2y1,x2y2,x2y3,x2y4,x2y5,x3y1,x3y2,x3y3,x3y4,x3y5,x4y1,x4y2,x4y3,x4y4,x4y5,x5y1,x5y2,x5y3,x5y4,x5y5;
    private Button btnGetCost;
    private TextView txtStauts,txtCost,txtPath;

    private List<Integer> minCostPathIndex ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize the xml views
        initGUI();

        //Button listener
        btnGetCost.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        //Check the button click listener
        if(v.getId()==R.id.btnGetCost){
            if(checkValidation()) //make condition true if we use hardcode values
            {
                minCostPathIndex =new ArrayList<>();
                initializeMatrix();
            }else {
                Toast.makeText(getApplicationContext(), "Pls enter all values", Toast.LENGTH_LONG).show();
            }

        }
    }
    private void initializeMatrix(){
         //int grid[][] = {{3,6,5,8,3},{4,1,9,4,7},{1,8,3,1,2},{2,2,9,3,8},{8,7,9,2,6},{6,4,5,6,4}};  //for hard coding grid as long as
         int grid[][]= {{Integer.parseInt(x1y1.getText().toString()),Integer.parseInt(x2y1.getText().toString()),
                        Integer.parseInt(x3y1.getText().toString()),Integer.parseInt(x4y1.getText().toString()),Integer.parseInt(x5y1.getText().toString())},
                {Integer.parseInt(x1y2.getText().toString()),Integer.parseInt(x2y2.getText().toString()),
                        Integer.parseInt(x3y2.getText().toString()),Integer.parseInt(x4y2.getText().toString()),Integer.parseInt(x5y2.getText().toString())},
                {Integer.parseInt(x1y3.getText().toString()),Integer.parseInt(x2y3.getText().toString()),
                        Integer.parseInt(x3y3.getText().toString()),Integer.parseInt(x4y3.getText().toString()),Integer.parseInt(x5y3.getText().toString())},
                {Integer.parseInt(x1y4.getText().toString()),Integer.parseInt(x2y4.getText().toString()),
                        Integer.parseInt(x3y4.getText().toString()),Integer.parseInt(x4y4.getText().toString()),Integer.parseInt(x5y4.getText().toString())},
                {Integer.parseInt(x1y5.getText().toString()),Integer.parseInt(x2y5.getText().toString()),
                        Integer.parseInt(x3y5.getText().toString()),Integer.parseInt(x4y5.getText().toString()),Integer.parseInt(x5y5.getText().toString())}

                };



       // Store the grid into  List<List<Integer>>
        List<List<Integer>> colList =new ArrayList<>();
        System.out.println("COl Size:"+grid.length);
        for(int k=0; k<grid.length ;k++){
            List<Integer> eachColList = new ArrayList<>();
            for (int i=0 ; i<grid[k].length ;i++){
                eachColList.add(grid[k][i]);
            }
            colList.add(eachColList);
        }

        int lastMinIndex;
        if(colList.size() > 0){
            lastMinIndex =getMinCost(colList.get(0));
            minCostPathIndex.add(lastMinIndex+1);
            for(int i=1 ; i< colList.size() ; i++){
                lastMinIndex = getMinCost(lastMinIndex ,colList.get(i));
                minCostPathIndex.add(lastMinIndex+1);
            }
        }


        //Find the BLogic status YES or NO
        if(grid.length == minCostPathIndex.size()) {
            txtStauts.setText("Yes");
        }else{
            txtStauts.setText("No");
        }


        //Find the total cost
        int costSum =0;
        for(int i=0; i < minCostPathIndex.size();i++){
            costSum+= grid[i][minCostPathIndex.get(i)-1];
        }
        txtCost.setText("Total Cost :"+costSum);

        //Print the path of the min cost
        txtPath.setText("Path :"+minCostPathIndex);
    }

    /**
     *  Find the min cost of  given list
     * @param firstList
     * @return minValue
     */
    private static int getMinCost(List<Integer> firstList){
        int minValueInFirstColPos = firstList.indexOf(Collections.min(firstList));
        return minValueInFirstColPos;
    }

    /**
     *  Find the min cost of  given list, Check in the list pos minVal-1,minVal,minVal+1
     *  Wrap minVal-1 if minVal is 0 and minVal max size equal to list
     * @param minVal
     * @param list
     * @return
     */
    private static int getMinCost(int minVal, List<Integer> list){
        int firstVal = 0,midVal = minVal,lastVal = 0;
        if(minVal == 0)
        {
            firstVal = list.size()-1;
        }else{
            firstVal = minVal-1;
        }
        if(minVal+1 == list.size())
        {
            lastVal = 0;
        }else{
            lastVal = minVal+1;
        }

        firstVal = list.get(firstVal);
        midVal = list.get(midVal);
        lastVal = list.get(lastVal);

        int minValAmong = Math.min(Math.min(firstVal, midVal), lastVal);
        return list.indexOf(minValAmong);
    }

    /**
     *  Initialize  and refer the XMl view's
     */
    private void initGUI(){
        x1y1 = (EditText) findViewById(R.id.x1y1);
        x1y2 = (EditText) findViewById(R.id.x1y2);
        x1y3= (EditText) findViewById(R.id.x1y3);
        x1y4 = (EditText) findViewById(R.id.x1y4);
        x1y5 = (EditText) findViewById(R.id.x1y5);

        x2y1 = (EditText) findViewById(R.id.x2y1);
        x2y2 = (EditText) findViewById(R.id.x2y2);
        x2y3= (EditText) findViewById(R.id.x2y3);
        x2y4 = (EditText) findViewById(R.id.x2y4);
        x2y5 = (EditText) findViewById(R.id.x2y5);

        x3y1 = (EditText) findViewById(R.id.x3y1);
        x3y2 = (EditText) findViewById(R.id.x3y2);
        x3y3= (EditText) findViewById(R.id.x3y3);
        x3y4 = (EditText) findViewById(R.id.x3y4);
        x3y5 = (EditText) findViewById(R.id.x3y5);

        x4y1 = (EditText) findViewById(R.id.x4y1);
        x4y2 = (EditText) findViewById(R.id.x4y2);
        x4y3= (EditText) findViewById(R.id.x4y3);
        x4y4 = (EditText) findViewById(R.id.x4y4);
        x4y5 = (EditText) findViewById(R.id.x4y5);

        x5y1 = (EditText) findViewById(R.id.x5y1);
        x5y2 = (EditText) findViewById(R.id.x5y2);
        x5y3= (EditText) findViewById(R.id.x5y3);
        x5y4 = (EditText) findViewById(R.id.x5y4);
        x5y5 = (EditText) findViewById(R.id.x5y5);

        btnGetCost = (Button) findViewById(R.id.btnGetCost);
        txtStauts = (TextView) findViewById(R.id.txtStatus);
        txtCost = (TextView) findViewById(R.id.txtCost);
        txtPath = (TextView) findViewById(R.id.txtPath);
    }


    /**
     *  Check all the fields are entered
     * @return true if all is enter the values
     */
    private boolean checkValidation(){
        if(x1y1.getText().toString().trim().length()>0&& x1y2.getText().toString().trim().length()>0 &&
           x1y3.getText().toString().trim().length()>0 && x1y4.getText().toString().trim().length()>0&&
           x1y5.getText().toString().trim().length()>0 &&
                x2y1.getText().toString().trim().length()>0&& x2y2.getText().toString().trim().length()>0 &&
                x2y3.getText().toString().trim().length()>0 && x2y4.getText().toString().trim().length()>0&&
                x2y5.getText().toString().trim().length()>0 &&
                x3y1.getText().toString().trim().length()>0&& x3y2.getText().toString().trim().length()>0 &&
                x3y3.getText().toString().trim().length()>0 && x3y4.getText().toString().trim().length()>0&&
                x3y5.getText().toString().trim().length()>0 &&
                x4y1.getText().toString().trim().length()>0&& x4y2.getText().toString().trim().length()>0 &&
                x4y3.getText().toString().trim().length()>0 && x4y4.getText().toString().trim().length()>0&&
                x4y5.getText().toString().trim().length()>0 &&
                x5y1.getText().toString().trim().length()>0&& x5y2.getText().toString().trim().length()>0 &&
                x5y3.getText().toString().trim().length()>0 && x5y4.getText().toString().trim().length()>0&&
                x5y5.getText().toString().trim().length()>0){
            return  true;
        }else {return false;}

    }
}
